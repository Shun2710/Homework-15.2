class GroupException(Exception):
    pass